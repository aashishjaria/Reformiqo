2023-08-29
==========

# Open applications

- All issues left open: 1
- Average days open: 32.0
- Median days open: 32.0

# Granted applications

- All granted: 329
- Average days to grant: 11.7
- Median days to grant: 7.0

# Notary Details

| Handle            |   Granted | Days to Grant Avg (Median)   |   Open | Days Left Open Avg (Median)   |   Closed (no grant) |
|-------------------|-----------|------------------------------|--------|-------------------------------|---------------------|
| 1475Notary        |         3 | 23.3  (8.9)                  |      0 | ....                          |                  13 |
| 1am5UP3RasM4R10   |         0 | ....                         |      0 | ....                          |                   2 |
| andrewxhill       |        12 | 11.3  (10.1)                 |      0 | ....                          |                  69 |
| BlockMakeronline  |         0 | ....                         |      0 | ....                          |                   1 |
| Broz221           |         7 | 12.9  (9.2)                  |      0 | ....                          |                  41 |
| cryptowhizzard    |         3 | 5.1  (2.7)                   |      0 | ....                          |                  39 |
| dannyob           |        27 | 5.3  (2.5)                   |      0 | ....                          |                 136 |
| DarnellWashington |         0 | ....                         |      0 | ....                          |                   6 |
| Destore2023       |        16 | 9.0  (2.5)                   |      0 | ....                          |                 122 |
| dkkapur           |         0 | ....                         |      0 | ....                          |                   3 |
| Fenbushi-Filecoin |         8 | 7.3  (5.6)                   |      0 | ....                          |                 104 |
| fireflyHZ         |         2 | 35.6  (35.6)                 |      0 | ....                          |                  11 |
| flyworker         |         0 | ....                         |      0 | ....                          |                   8 |
| IPFSUnion         |         7 | 14.0  (9.2)                  |      0 | ....                          |                  33 |
| IreneYoung        |         8 | 21.2  (15.7)                 |      0 | ....                          |                  76 |
| jamerduhgamer     |         2 | 2.1  (2.1)                   |      0 | ....                          |                  10 |
| Joss-Hua          |         0 | ....                         |      0 | ....                          |                  11 |
| jsonsivar         |         0 | ....                         |      0 | ....                          |                  13 |
| junyaoren         |         0 | ....                         |      0 | ....                          |                   1 |
| KodaRobotDog      |         2 | 6.9  (6.9)                   |      0 | ....                          |                   8 |
| llifezou          |         2 | 3.1  (3.1)                   |      0 | ....                          |                   2 |
| MasaakiNawatani   |        29 | 14.8  (9.9)                  |      0 | ....                          |                 131 |
| MatrixStorage     |         1 | 0.3  (0.3)                   |      0 | ....                          |                   4 |
| MegTei            |        10 | 10.1  (9.5)                  |      0 | ....                          |                  29 |
| MRJAVAZHAO        |        29 | 6.4  (5.8)                   |      0 | ....                          |                 135 |
| neogeweb3         |        43 | 12.4  (8.4)                  |      0 | ....                          |                 145 |
| newwebgroup       |         0 | ....                         |      0 | ....                          |                  18 |
| NiwanDao          |         0 | ....                         |      0 | ....                          |                   4 |
| ozhtdong          |        11 | 9.3  (5.9)                   |      0 | ....                          |                 107 |
| philippbanhardt   |        18 | 7.9  (6.7)                   |      0 | ....                          |                  81 |
| PluskitOfficial   |         0 | ....                         |      0 | ....                          |                   4 |
| psh0691           |         0 | ....                         |      0 | ....                          |                   3 |
| rayshitou         |        12 | 42.5  (40.0)                 |      0 | ....                          |                  62 |
| Rin-huang         |         2 | 32.4  (32.4)                 |      0 | ....                          |                   2 |
| s0nik42           |        12 | 10.2  (1.8)                  |      1 | 32.0  (32.0)                  |                  51 |
| simonkim0515      |         0 | ....                         |      0 | ....                          |                   2 |
| steven004         |        45 | 11.5  (7.0)                  |      0 | ....                          |                 200 |
| TimWilliams00     |         0 | ....                         |      0 | ....                          |                  15 |
| wjywood           |         0 | ....                         |      0 | ....                          |                  39 |
| xinaxu            |         0 | ....                         |      0 | ....                          |                   8 |
| XnMatrixSV        |        18 | 6.5  (6.1)                   |      0 | ....                          |                  39 |